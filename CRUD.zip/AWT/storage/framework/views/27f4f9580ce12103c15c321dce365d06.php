<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Apple</title>
        <link rel="icon" type="image/x-icon" href="assets/Logo.png" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <link href="<?php echo e(asset('assets/css/styles.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet" />
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <link rel="icon" type="image/x-icon" href="assets/Logo.png" />
                <a class="navbar-brand" href="index.html">APPLE</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <h3>
                    <a href="<?php echo e(url('/login')); ?>" class="btn btn-primary btn-sm text-white">Login</a>
                    <a href="<?php echo e(url('/registration')); ?>" class="btn btn-primary btn-sm text-white">Registation</a>
                </h3>
            </div>
        </nav>

        <header class="bg-dark py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">We Built Different.....</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Discover the World in Every Pixel: iPhone – Where Innovation Meets Imagination</p>
                </div>
            </div>
        </header>
        <section class="py-5">
            <center>
                <h1 class="display-4 fw-bolder">Which iPhone is right for you?</h1>
            </center>
            <div class="container px-4 px-lg-5 mt-5">
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                    <div class="col mb-5">
                        <div class="card h-100">
                            <img class="card-img-top" src="<?php echo e(asset('uploads/products/16973933911.jpg')); ?>" alt="..." />
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <h5 class="fw-bolder">Iphone 15</h5>
                                </div>
                            </div>
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="<?php echo e(url('/login')); ?>">View Details</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col mb-5">
                        <div class="card h-100">
                            <img class="card-img-top" src="<?php echo e(asset('uploads/products/16973934631.jpg')); ?>" alt="..." />
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <h5 class="fw-bolder">Iphone 14</h5>
                                </div>
                            </div>
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="<?php echo e(url('/login')); ?>">View Details</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Iphone 2023</p></div>
        </footer>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Assignment\AWT\resources\views/welcome.blade.php ENDPATH**/ ?>