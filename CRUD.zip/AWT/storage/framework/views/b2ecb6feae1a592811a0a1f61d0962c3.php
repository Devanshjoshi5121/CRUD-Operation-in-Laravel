<!DOCTYPE html>
<html>
  <head>
    <title>Laravel Login form</title>
    <style>
      body {
        font-family: Arial, Helvetica, sans-serif;
      }
      * {
        box-sizing: border-box;
      }
      input[type=text],
      select,
      textarea {
        width: 100%;
        padding: 8px;
        border: 1px solid #eeeeee;
        border-radius: 4px;
        box-sizing: border-box;
        margin-top: 8px;
        margin-bottom: 16px;
        resize: vertical;
      }
      input[type=submit] {
        background-color: #4cd9c6;
        color: #ffffff;
        padding: 12px 20px;
        border: none;
        border-radius: 7px;
        cursor: pointer;
      }
      input[type=submit]:hover {
        background-color: #6fe8d7;
      }
      .container {
        border-radius: 8px;
        background-color: #e6e6e6;
        padding: 15px;
      }
    </style>
  </head>
  <body>
    <h2>login Form</h2>
    <div class="container">
      <form action="/form/submit" method="POST">
        <label for="fname">Name</label>
        <input type="text" id="fname" name="name" placeholder="Type your name..">
        <label for="lname">Last Name</label>
        <input type="text" id="lname" name="surname" placeholder="Type your last name..">
        <label for="lname">E-mail Address</label>
        <input type="text" id="mail" name="e-mail" placeholder="Type your e-mail..">
        <label for="ci">Country</label>
        <label for="message">Message</label>
        <textarea id="message" name="message" placeholder="Type your message.." style="height:200px"></textarea>
        <input type="submit" value="Send">
      </form>
    </div>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\Assignment\AWT\resources\views/products/login.blade.php ENDPATH**/ ?>