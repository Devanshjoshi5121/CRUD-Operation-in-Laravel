<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Product View Detail Page</title>

    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
</head>
<body>
    <div class="py-3 py-md-5 bg-light">
        <div class="container">
            <div class="row">
            <?php if(session('message')): ?>
                    <div class="alert alert-success mb-3"><?php echo e(session('message')); ?></div>
            <?php endif; ?>
                <div class="col-md-5 mt-3">
                    <div class="bg-white border" wire:ignore>
                            <img src="<?php echo e(asset($product->productImages[0]->image)); ?>" alt="Img" width="350" height="400">
                    </div>
                </div>
                <div class="col-md-7 mt-3">
                    <div class="product-view">
                        <h4 class="product-name">
                            <?php echo e($product->name); ?>

                        </h4>
                        <hr>
                        <p class="product-path">
                            Home /<?php echo e($product->name); ?>

                        </p>
                        <div>
                            <span class="selling-price">₹<?php echo e($product->selling_price); ?></span>
                            <span class="original-price">₹<?php echo e($product->original_price); ?></span>
                        </div>

                        <div class="mt-2">
                            <div class="input-group">
                                <span class="btn btn1" wire:click="decrementQuantity"><i class="fa fa-minus"></i></span>
                                <input type="text" wire:model="quantityCount" value="1"
                                    readonly class="input-quantity" />
                                <span class="btn btn1" wire:click="incrementQuantity"><i class="fa fa-plus"></i></span>
                            </div>
                        </div>

                        <div class="mt-2">
                            <button type="button" wire:click="addToCart(<?php echo e($product->id); ?>)" class="btn btn1">
                                <span wire:loading.remove wire:target="addToCart">
                                    <i class="fa fa-heart"></i> Add To Cart
                                </span>
                            </button>
                            <button type="button" wire:click="addToWishList(<?php echo e($product->id); ?>)" class="btn btn1">
                                <span wire:loading.remove wire:target="addToWishList">
                                    <i class="fa fa-heart"></i> Add To Wishlist
                                </span>
                            </button>

                        </div>
                        <div class="mt-3">
                            <h5 class="mb-0">Small Description</h5>
                            <p>
                                <?php echo $product->small_description; ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 mt-3">
                    <div class="card">
                        <div class="card-header bg-white">
                            <h4>Description</h4>
                        </div>
                        <div class="card-body">
                            <p>
                                <?php echo $product->description; ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\Assignment\AWT\resources\views/products/view.blade.php ENDPATH**/ ?>