<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Product View</title>

    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
</head>
<body>
<div>
<center>
    <h2>Product Page</h2>
    <div class="product-name">
        <button class="btn btn-lg">
            <a href="<?php echo e(url('/products')); ?>">Admin Page</a>
        </button>
    </div>
    <br/>
    <div class="col-md-9">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4">
                    <div class="product-card">
                        <div class="product-card-img">
                            <?php if($productItem->productImages->count() > 0): ?>
                                <img src="<?php echo e(asset($productItem->productImages[0]->image)); ?>" alt="<?php echo e($productItem->name); ?>">
                            <?php endif; ?>
                        </div>
                        <div class="product-card-body">
                            
                            <h5 class="product-name">
                                <?php echo e($productItem->name); ?>

                            <button class="btn btn-outline-dark">
                                <a
                                    href="<?php echo e(url('/view' . '/' . $productItem->slug)); ?>">View Product
                                </a>
                            </button>
                            </h5>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-md-12">
                    <div class="p-2">
                        <h4>No product Available</h4>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</center>
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Assignment\AWT\resources\views/products/index.blade.php ENDPATH**/ ?>