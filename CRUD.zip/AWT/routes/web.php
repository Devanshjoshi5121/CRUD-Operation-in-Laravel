<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

//Custom Auth
Route::controller(App\Http\Controllers\Admin\CustomAuthConroller::class)->group(function () {
    Route::get('/login', 'login');
    Route::get('/registration', 'registration');
    Route::post('/register-user', 'registerUser');
    Route::post('/login-user', 'loginUser');
    Route::get('/dashboard', 'dashboard');
    Route::get('/logout', 'logout');
    Route::get('/', 'home');
});

//Product
Route::controller(App\Http\Controllers\Admin\ProductController::class)->group(function () {
    Route::get('/products', 'index');
    Route::get('/products/create', 'create');
    Route::post('/products', 'store');
    Route::get('/products/{product}/edit', 'edit');
    Route::put('/products/{product}','update');
    Route::get('products/{product_id}/delete','destroy');
    Route::get('product-image/{product_image_id}/delete','destroyImage');
});

//View
Route::controller(App\Http\Controllers\Admin\ViewController::class)->group(function () {
    Route::get('/view', 'index');
    Route::get('/view/{product_slug}', 'productview');
});