<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Product View</title>

    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/css/custom.css') }}">
</head>
<body>
<div>
<center>
    <h2>Product Page</h2>
    <div class="product-name">
        <button class="btn btn-lg">
            <a href="{{ url('/products') }}">Admin Page</a>
        </button>
    </div>
    <br/>
    <div class="col-md-9">
        <div class="row">
            @forelse ($products as $productItem)
                <div class="col-md-4">
                    <div class="product-card">
                        <div class="product-card-img">
                            @if ($productItem->productImages->count() > 0)
                                <img src="{{ asset($productItem->productImages[0]->image) }}" alt="{{ $productItem->name }}">
                            @endif
                        </div>
                        <div class="product-card-body">
                            {{-- <p class="product-brand">{{ $productItem->brand }}</p> --}}
                            <h5 class="product-name">
                                {{ $productItem->name }}
                            <button class="btn btn-outline-dark">
                                <a
                                    href="{{ url('/view' . '/' . $productItem->slug) }}">View Product
                                </a>
                            </button>
                            </h5>
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-md-12">
                    <div class="p-2">
                        <h4>No product Available</h4>
                    </div>
                </div>
            @endforelse
        </div>
    </div>
</center>
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
