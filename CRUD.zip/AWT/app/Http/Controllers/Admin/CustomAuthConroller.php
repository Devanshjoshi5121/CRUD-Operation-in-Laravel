<?php

namespace App\Http\Controllers\Admin;

use App\Models\UserAuth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class CustomAuthConroller extends Controller
{
    public function login()
    {
        return view('admin.login');
    }

    public function registration()
    {
        return view('admin.registration');
    }

    public function registerUser(Request $request)
    {
        // return view('admin.registration');
        // echo 'value posted';
        $request->validate([
            'name'=>'required',
            'email'=>'required|email|unique:user_auths',
            'password'=>'required|min:5|max:12',
        ]);
        UserAuth::create([
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>Hash::make($request->password),
        ]);
        if(Auth::attempt($request->only('email','password')))
        {
            return redirect('/view');
        }

        return redirect('/registration')->withError('Error');
    }

    public function loginUser(Request $request)
    {
        $request->validate([
            'email'=>'required|email',
            'password'=>'required|min:5|max:12',
        ]);
        $user = UserAuth::where('email','=',$request->email)->first();
        if($user){
            if(Hash::check($request->password,$user->password)){
                $request->session()->put('loginId',$user->id);
                return redirect('/view');
            }
            else{
                return back()->with('fail','Password Did not matched');
            }
        }else{
            return back()->with('fail','User is not registered');
        }
    }

    public function dashboard()
    {
        $data = array();
        if(Session::has('loginId')){
        $data = UserAuth::where('Id','=',Session::get('loginId'))->first();
        }
        return view('dashboard',compact('data'));
    }

    public function logout()
    {
        if(session::has('loginId')){
            Session::pull('loginId');
            return redirect('login');
        }
    }

    public function home()
    {
        return view('welcome');
    }
}