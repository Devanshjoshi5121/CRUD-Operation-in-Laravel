<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductImage;
use Illuminate\Http\Request;

class ViewController extends Controller
{
    public function index()
    {
        $products = Product::all();
        return view('products.index',compact('products'));
    }

    public function productview(string $product_slug)
    {
        // $product = Product::where('slug',$product_slug)->first();
        $product = product::where('slug', $product_slug)->where('status','0')->first();
        if($product)
        {
            return view('products.view', compact('product'));
        }else{
            return redirect()->back();
        }
    }
}